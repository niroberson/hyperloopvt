 ////////////////////////////////////////////////////////////////////////////////////
// ECE 2534:        HW6
// File name:       LePelch_Alex_HW6.c
// Description:     The following code implements an accelerometer register read through the SPI communication protocol
// Resources:       LePelch_Alex_Lab3.c PmodOLED.c uses SPI1 for communication with the OLED.
// Written by:      Alex LePelch
// Last modified:   11/14/2014

#define _PLIB_DISABLE_LEGACY
#include <plib.h>
#include "PmodOLED.h"
#include "OledChar.h"
#include "OledGrph.h"
#include "delay.h"
#include "spi_5xx_6xx_7xx.h"

// Digilent board configuration
#pragma config ICESEL       = ICS_PGx1  // ICE/ICD Comm Channel Select
#pragma config DEBUG        = OFF       // Debugger Disabled for Starter Kit
#pragma config FNOSC        = PRIPLL	// Oscillator selection
#pragma config POSCMOD      = XT	// Primary oscillator mode
#pragma config FPLLIDIV     = DIV_2	// PLL input divider
#pragma config FPLLMUL      = MUL_20	// PLL multiplier
#pragma config FPLLODIV     = DIV_1	// PLL output divider
#pragma config FPBDIV       = DIV_8	// Peripheral bus clock divider
#pragma config FSOSCEN      = OFF	// Secondary oscillator enable

//Function prototypes
void initOLED (void);//Initialize OLED
void initSPI(SpiChannel chn, unsigned int srcClkDiv); //Initialize SPI, inputs SPI channel and Desired clock frequency
void setAccelReg(SpiChannel chn, unsigned int address, unsigned int data);//Inputs SPI channel, intended address, and data to send, sets value of data into address
int getAccelReg(SpiChannel chn, unsigned int address);//Inputs SPI channel and intended accelerometer address, returns data received
void initAccelerometer(SpiChannel chn);//Initialize Accelerometer, inputs SPI channel number
int getAccelData(SpiChannel chn, int accelData);//Inputs SPI channel and accelData number, returns either X,Y, or Z axis accelerometer readings

//Global Variables
unsigned int oneSecond;         //one second variale
unsigned int milliSecond;       //milli seconds variable
unsigned int joyLR;             //Joystick left right value
unsigned int joyUD;             //Joystick up down value

static const int DATAX0 = 0x32 | 0x80; //Read only
static const int DATAX1 = 0x33 | 0x80; //Read only
static const int DATAY0 = 0x34 | 0x80; //Read only
static const int DATAY1 = 0x35 | 0x80; //Read only
static const int DATAZ0 = 0x36 | 0x80; //Read only
static const int DATAZ1 = 0x37 | 0x80; //Read only
static const int POWER_CTL = 0x2D;     //Porwer-Control Register
static const int BW_RATE = 0x2C;       //BW_Rate register
static const int DATA_FORMAT = 0x31;   //Data-Format Register
static const int DEV_ID = 0x00 | 0x80; //Read only
unsigned int garbage;         //Garbage data

void initSPI(SpiChannel chn, unsigned int srcClkDiv )
{
    SpiChnOpen(chn,
               SPI_OPEN_MSTEN|SPI_OPEN_MSSEN|SPI_OPEN_CKP_HIGH|SPI_OPEN_MODE8|SPI_OPEN_ENHBUF,
               srcClkDiv);
    return;
}

void setAccelReg(SpiChannel chn, unsigned int address, unsigned int data)
{
    SpiChnPutC(chn, address);
    SpiChnPutC(chn, data);
    SpiChnGetC(chn);
    SpiChnGetC(chn);
    return;
}

int getAccelReg(SpiChannel chn, unsigned int address)
{
    int data;
    SpiChnPutC(chn, address);
    SpiChnPutC(chn, garbage);
    SpiChnGetC(chn);
    data = SpiChnGetC(chn);
    return data;
}

void initAccelerometer(SpiChannel chn)
{
    setAccelReg(chn, DATA_FORMAT, 0x9);
    setAccelReg(chn, BW_RATE, 0xC);
    setAccelReg(chn, POWER_CTL, 0x8);

    return;
}

int getAccelData(SpiChannel chn, int accelData)
{
    int dataX0, dataX1, dataY0, dataY1, dataZ0, dataZ1, accelDataReturn;

    dataX0 = getAccelReg(chn, DATAX0);
    dataX1 = getAccelReg(chn, DATAX1);

    dataY0 = getAccelReg(chn, DATAY0);
    dataY1 = getAccelReg(chn, DATAY1);

    dataZ0 = getAccelReg(chn, DATAZ0);
    dataZ1 = getAccelReg(chn, DATAZ1);

    BYTE dataY0B = (BYTE)dataY0;
    BYTE dataY1B = (BYTE)dataY1;
    int dataY = dataY1B << 8;
    dataY = dataY | dataY0B;
    
    BYTE dataZ0B = (BYTE)dataZ0;
    BYTE dataZ1B = (BYTE)dataZ1;
    int dataZ = dataZ1B << 8;
    dataZ = dataZ | dataZ0B;

    BYTE dataX0B = (BYTE)dataX0;
    BYTE dataX1B = (BYTE)dataX1;
    int dataX = dataX1B << 8;
    dataX = dataX | dataX0B;

    if(dataX & 0x8000) dataX = dataX | 0xFFFF0000;
    if(dataY & 0x8000) dataY = dataY | 0xFFFF0000;
    if(dataZ & 0x8000) dataZ = dataZ | 0xFFFF0000;

    if(accelData == 0) accelDataReturn = dataX;
    else if(accelData == 1) accelDataReturn = dataY;
    else accelDataReturn = dataZ;

    return accelDataReturn;
}

void initOLED (void)
{
    DelayInit();
    OledInit();
    OledClearBuffer();
    return;
}

int main()
{
    SpiChannel chn = SPI_CHANNEL3;
    enum states {init, SPI} state;
    state = init;

    while(1)
    {
        switch(state)
        {
            case init:
            {
                unsigned int srcClkDiv = 10000000/10;

                initOLED();
                initSPI(chn, srcClkDiv);
                initAccelerometer(chn);
                state = SPI;
                break;
            }

            case SPI:
            { 
                int  deviceID,dataX0, dataX1, dataY0, dataY1, dataZ0, dataZ1, accelData[3];
                char buf[17], buf1[17], buf2[17], buf3[17];
    
                accelData[0] = getAccelData(chn, 0);
                accelData[1] = getAccelData(chn, 1);
                accelData[2] = getAccelData(chn, 2);

                sprintf(buf3, "Y: %+5d", accelData[0]);
                OledSetCursor(0,2);
                OledPutString(buf3);

                sprintf(buf1, "X: %+5d", accelData[1]);
                OledSetCursor(0,1);
                OledPutString(buf1);

                sprintf(buf2, "Z: %+5d", accelData[2]);
                OledSetCursor(0,3);
                OledPutString(buf2);

                deviceID = getAccelReg(chn, DEV_ID);
                sprintf(buf, "Accel Test  %2X", deviceID);
                OledSetCursor(0,0);
                OledPutString(buf);

                state = SPI;
                break;

            }
        }
    }
    return 0;
}

