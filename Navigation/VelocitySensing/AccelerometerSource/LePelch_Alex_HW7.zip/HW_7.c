    ////////////////////////////////////////////////////////////////////////////////////
// ECE 2534:        HW6
// File name:       LePelch_Alex_HW7.c
// Description:     The following code implements an acceleromter register read to obtain acceleration data in the
//                  X, Y , and Z components.
// Resources:       LePelch_Alex_Lab3.c     PmodOLED.c uses SPI1 for communication with the OLED.
//
// Written by:      Alex LePelch
// Last modified:   10/30/2014

#define _PLIB_DISABLE_LEGACY
#include <plib.h>
#include "PmodOLED.h"
#include "OledChar.h"
#include "OledGrph.h"
#include "delay.h"
#include "spi_5xx_6xx_7xx.h"
#include "i2c.h"

// Digilent board configuration
#pragma config ICESEL       = ICS_PGx1  // ICE/ICD Comm Channel Select
#pragma config DEBUG        = OFF       // Debugger Disabled for Starter Kit
#pragma config FNOSC        = PRIPLL	// Oscillator selection
#pragma config POSCMOD      = XT	// Primary oscillator mode
#pragma config FPLLIDIV     = DIV_2	// PLL input divider
#pragma config FPLLMUL      = MUL_20	// PLL multiplier
#pragma config FPLLODIV     = DIV_1	// PLL output divider
#pragma config FPBDIV       = DIV_8	// Peripheral bus clock divider
#pragma config FSOSCEN      = OFF	// Secondary oscillator enable

//Function prototypes
void initOLED (void);//Initialize OLED
void initTimer(void);//Initialize Timer

//I2C Prototypes
BYTE accelGetReg(I2C_MODULE bus, BYTE address); //Accelerometer register read, returns one Byte of data corresponding to a x,y, or z component. Inputs desired I2C bus and acceleromter address
void accelSetReg(I2C_MODULE bus, BYTE address, BYTE data); //Set data values in accelerometer register
void accelInit(I2C_MODULE bus); //Initialize the accelerometer
int accelGetData(I2C_MODULE bus, int accelData); //Get X, Y, Z data from accelerometer

void initI2C(I2C_MODULE bus, unsigned int sourceClock, unsigned int i2cClock, BOOL enable); //Initializes the I2C module by inputing desired I2C bus, the source clock, desired i2C clock frequency, and a BOOL for I2C enable.
void StartBus(I2C_MODULE bus); //Start the I2C bus, inputs desired bus
void RepeatStartBus(I2C_MODULE bus); //Repeat start bus, inputs desired I2C bus
void SendByte(I2C_MODULE bus, BYTE data); //Send a byte via 12C, inputs desired I2C bus and data byte to send
BYTE ReadByte(I2C_MODULE bus, BOOL ack); //Inputs desired I2C bus, acknowledge to send (ACK or NACK) and returns BYTE of data received from accelerometer
void StopBus(I2C_MODULE bus); //Stop I2C bus, inputs desired I2C bus

static const int accelWrite = 0x3A; //Slave address write
static const int accelRead = 0x3B;  //Slave address read
static const int DATAX0 = 0x32 | 0x80; //Read only
static const int DATAX1 = 0x33 | 0x80; //Read only
static const int DATAY0 = 0x34 | 0x80; //Read only
static const int DATAY1 = 0x35 | 0x80; //Read only
static const int DATAZ0 = 0x36 | 0x80; //Read only
static const int DATAZ1 = 0x37 | 0x80; //Read only
static const int POWER_CTL = 0x2D;     //Porwer-Control Register
static const int BW_RATE = 0x2C;       //BW_Rate register
static const int DATA_FORMAT = 0x31;   //Data-Format Register
static const int DEV_ID = 0x00 | 0x80; //Device ID Register read

int accelGetData(I2C_MODULE bus, int accelData)
{
    int accelDataReturn;
    BYTE dataX0, dataX1, dataY0, dataY1, dataZ0, dataZ1;

    dataX0 = accelGetReg(bus, DATAX0); //Read X-component regesiter one
    dataX1 = accelGetReg(bus, DATAX1); //Read X-component register two

    int dataX = dataX1 << 8; //Shift register data two to 8 most significant locations
    dataX = dataX | dataX0; //Put the least 8 significant bits into last 8 locations of int dataX

    dataY0 = accelGetReg(bus, DATAY0);
    dataY1 = accelGetReg(bus, DATAY1);

    int dataY = dataY1 << 8;
    dataY = dataY | dataY0;

    dataZ0 = accelGetReg(bus, DATAZ0);
    dataZ1 = accelGetReg(bus, DATAZ1);

    int dataZ = dataZ1 << 8;
    dataZ = dataZ | dataZ0;

    if(dataX & 0x8000) dataX = dataX | 0xFFFF0000; //If most significant bit is 1 (negative), flip the sign
    if(dataY & 0x8000) dataY = dataY | 0xFFFF0000;
    if(dataZ & 0x8000) dataZ = dataZ | 0xFFFF0000;

    if(accelData == 0) accelDataReturn = dataX;
    else if(accelData == 1) accelDataReturn = dataY;
    else accelDataReturn = dataZ;

    return accelDataReturn;
}

void accelInit(I2C_MODULE bus)
{
    accelSetReg(bus, DATA_FORMAT, 0x9);
    accelSetReg(bus, BW_RATE, 0xC);
    accelSetReg(bus, POWER_CTL, 0x8);
}

void accelSetReg(I2C_MODULE bus, BYTE address, BYTE data)
{
    StartBus(bus);
    SendByte(bus, accelWrite);
    SendByte(bus, address);
    SendByte(bus, data);
    StopBus(bus);
}

BYTE accelGetReg(I2C_MODULE bus, BYTE address)
{
    BOOL ack = FALSE;
    BYTE data;

    StartBus(bus);
    SendByte(bus, accelWrite);
    SendByte(bus, address);
    RepeatStartBus(bus);
    SendByte(bus, accelRead);
    data = ReadByte(bus, ack);
    StopBus(bus);

    return data;
}

void initI2C(I2C_MODULE bus, unsigned int sourceClock, unsigned int i2cClock, BOOL enable)
{
    UINT32 actualClock;
    I2CConfigure(bus, 0);
    actualClock = I2CSetFrequency(bus, sourceClock, i2cClock);
    I2CEnable(bus, enable);
}

void StartBus(I2C_MODULE bus)
{
    while(!(I2CBusIsIdle(bus))) //While bus is not idle, do nothing
    {
    }

    I2CStart(bus); //Start bit send
    while(!(I2CGetStatus(bus) & I2C_START)) //While status is not I2C_Start, do nothing
    {
    }
}

void RepeatStartBus(I2C_MODULE bus)
{
    I2CRepeatStart(bus);
    while(!(I2CGetStatus(bus) & I2C_START)) //While status is not I2C_Start, do nothing
    {
    }
}

void SendByte(I2C_MODULE bus, BYTE data)
{
    while(!I2CTransmitterIsReady(bus)) //While transmitter not ready, do nothing
    {

    }

    I2CSendByte(bus, data);

    while(!I2CTransmissionHasCompleted(bus)) //While transmission not complete, do nothing
    {

    }

    while(!I2CByteWasAcknowledged(bus)) //While byte is not aknowledged, do nothing
    {
     
    }
}

BYTE ReadByte(I2C_MODULE bus, BOOL ack)
{
    BYTE data;
    I2CReceiverEnable (bus, TRUE);
    while(!I2CReceivedDataIsAvailable(bus)) //While received data is not available, do nothing
    {

    }
    I2CAcknowledgeByte(bus, ack);
    while(!I2CAcknowledgeHasCompleted(bus)) //While acknowledge has not completes, do nothing
    {

    }

    data = I2CGetByte(bus);
    
    return data;
}

void StopBus(I2C_MODULE bus)
{
    I2CStop(bus);
    while(!(I2CGetStatus(bus) & I2C_STOP)) //While status does not return I2C_STOP, do nothing
    {
        
    }
}

int main()
{
    I2C_MODULE bus = I2C2; //I2C Bus used
    UINT32 sourceClock = 10000000;
    UINT32 i2cClock = 100000; //100kHz I2C clock frequency
    BOOL enable = TRUE;

    char buf[17];
    enum states {init, I2C} state;
    state = init;

    while(1)
    {
        switch(state)
        {
            case init: //In this state, we initialize parameters such as OLED, timer, I2C bus, etc.
            {
                initTimer();
                initOLED();
                initI2C(bus, sourceClock, i2cClock, enable);
                accelInit(bus);
                state = I2C;
                break;
            }

            case I2C: //This state uses an I2C bus to receive data from accelerometer and display it onto an OLED module
            {
                BYTE devID;
                int  deviceID,dataX0, dataX1, dataY0, dataY1, dataZ0, dataZ1, accelData[3];
                char buf[17], buf1[17], buf2[17], buf3[17];

                accelData[0] = accelGetData(bus, 0);
                accelData[1] = accelGetData(bus, 1);
                accelData[2] = accelGetData(bus, 2);

                //Output data to OLED display
                devID = accelGetReg(bus, DEV_ID);
                sprintf(buf, "Accel Test : %2X", devID);
                OledSetCursor(0,0);
                OledPutString(buf);

                sprintf(buf1, "X: %+5d", accelData[0]);
                OledSetCursor(0,1);
                OledPutString(buf1);

                sprintf(buf2, "Y: %+5d", accelData[1]);
                OledSetCursor(0,2);
                OledPutString(buf2);

                sprintf(buf3, "Z: %+5d", accelData[2]);
                OledSetCursor(0,3);
                OledPutString(buf3);

                state = I2C;
                break;
            }
        }
    }
    return 0;
}

void initOLED (void)
{
    OledInit();
    OledClearBuffer();
    return;
}

void initTimer(void)
{
    DelayInit();
    OpenTimer2(T2_ON | T2_IDLE_CON | T2_SOURCE_INT | T2_PS_1_16 | T23_GATE_OFF, 624);
    return;
}



